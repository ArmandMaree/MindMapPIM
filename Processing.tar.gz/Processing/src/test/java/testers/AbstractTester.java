package testers;

import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
* The AbstractTest class is the parent of all JUnit test classes. This class
* configures the test ApplicationContext and test runner environment.
* 
* @author Armand Maree
* @since 2016-07-
*/
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = main.Application.class)
public abstract class AbstractTester {

    /**
    * The Logger instance for all classes in the unit test framework.
    */
    protected Logger logger = LoggerFactory.getLogger(this.getClass());

}